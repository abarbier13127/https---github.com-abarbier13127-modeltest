#!/usr/bin/env python3
"""Les trois outils de recherche du RAG AiDocs, sur PGVector.

Chaque outil est une fonction indépendante (future API / outil d'agent) :
  - vector_search  : similarité sémantique (e5-small + index HNSW cosinus)
  - keyword_search : plein texte PostgreSQL (tsvector + index GIN)
  - graph_links    : pages liées à une page (liens sortants et entrants)

Connexion PostgreSQL : variables libpq (PGHOST, PGUSER, PGPASSWORD...).

Usage :
    python search.py vector  "how do pods share storage?"
    python search.py keyword "PersistentVolumeClaim access modes"
    python search.py graph   /docs/concepts/workloads/pods/
"""

import os
import re
import sys

import numpy as np
import psycopg
import requests

CORPUS = "k8s-website"
# Termes à rechercher aussi littéralement : camelCase, chemin pointé, snake/kebab-case.
IDENTIFIER = re.compile(r"^(?=.*[a-z])(?:\w+[./]\w[\w./]*|[a-z]+[A-Z]\w*|\w+[_-]\w+)$")
EMBED_URL = os.environ.get(
    "EMBED_URL", "http://e5-small-predictor.aidocs.svc.cluster.local:8080/v1/embeddings"
)
EMBED_MODEL = os.environ.get("EMBED_MODEL", "e5-small")


def embed_query(text):
    r = requests.post(
        EMBED_URL, json={"model": EMBED_MODEL, "input": [f"query: {text}"]}, timeout=60
    )
    r.raise_for_status()
    v = np.asarray(r.json()["data"][0]["embedding"], dtype=np.float32)
    v /= np.linalg.norm(v)
    return "[" + ",".join(f"{x:.6f}" for x in v) + "]"


def vector_search(conn, question, k=5):
    return conn.execute(
        """
        SELECT d.url_path, d.title, c.heading, c.content,
               1 - (c.embedding <=> %(q)s::vector) AS score
        FROM chunks c JOIN documents d ON d.id = c.document_id
        WHERE d.corpus = %(corpus)s
        ORDER BY c.embedding <=> %(q)s::vector
        LIMIT %(k)s
        """,
        {"q": embed_query(question), "corpus": CORPUS, "k": k},
    ).fetchall()


def keyword_search(conn, query, k=5):
    """Plein texte, avec repli littéral sur les identifiants.

    L'analyseur PostgreSQL classe `.spec.podManagementPolicy` en token « host » et en
    fait un lexème unique `spec.podmanagementpolici` : chercher le champ seul ne
    correspond alors à rien, alors que la doc Kubernetes écrit ses champs ainsi partout
    (constaté le 2026-09-21). On complète donc la `tsquery` par une correspondance
    littérale sur les termes qui ressemblent à des identifiants — camelCase, chemin
    pointé, ou mot porteur d'un underscore/tiret. Corpus de quelques milliers de chunks :
    le coût du ILIKE est négligeable.
    """
    literals = [t.strip("`.,()[]\"'") for t in query.split()]
    literals = [t for t in literals if IDENTIFIER.match(t)]
    return conn.execute(
        """
        WITH q AS (SELECT websearch_to_tsquery('english', %(q)s) AS tsq),
        matched AS (
            SELECT c.id, c.document_id, c.heading, c.content,
                   ts_rank_cd(c.tsv, q.tsq) AS score
            FROM chunks c, q
            WHERE c.tsv @@ q.tsq
            UNION
            -- repli littéral : score fixe, au-dessus du bruit de ts_rank_cd
            SELECT c.id, c.document_id, c.heading, c.content, 1.0 AS score
            FROM chunks c
            WHERE %(literals)s <> '{}'
              AND EXISTS (SELECT 1 FROM unnest(%(literals)s::text[]) lit
                          WHERE c.content ILIKE '%%' || lit || '%%')
        )
        SELECT d.url_path, d.title, m.heading, m.content, max(m.score) AS score
        FROM matched m JOIN documents d ON d.id = m.document_id
        WHERE d.corpus = %(corpus)s
        GROUP BY d.url_path, d.title, m.heading, m.content
        ORDER BY score DESC
        LIMIT %(k)s
        """,
        {"q": query, "corpus": CORPUS, "k": k, "literals": literals},
    ).fetchall()


def graph_links(conn, url_path):
    """Liens sortants et entrants d'une page. `ingested` : la cible est-elle en base ?"""
    url_path = "/" + url_path.strip("/") + "/"
    outgoing = conn.execute(
        """
        SELECT l.target_url, coalesce(t.title, l.anchor_text), t.id IS NOT NULL AS ingested
        FROM links l
        JOIN documents s ON s.id = l.source_id
        LEFT JOIN documents t ON t.corpus = s.corpus AND t.url_path = l.target_url
        WHERE s.corpus = %s AND s.url_path = %s
        ORDER BY ingested DESC, l.target_url
        """,
        (CORPUS, url_path),
    ).fetchall()
    incoming = conn.execute(
        """
        SELECT s.url_path, s.title, true
        FROM links l JOIN documents s ON s.id = l.source_id
        WHERE s.corpus = %s AND l.target_url = %s
        ORDER BY s.url_path
        """,
        (CORPUS, url_path),
    ).fetchall()
    return outgoing, incoming


def _print_chunks(rows):
    for url, title, heading, content, score in rows:
        snippet = " ".join(content.split())[:220]
        print(f"\n[{score:.3f}] {title} — {heading or '(intro)'}\n        {url}\n        {snippet}…")


def main():
    if len(sys.argv) < 3 or sys.argv[1] not in ("vector", "keyword", "graph"):
        print(__doc__)
        return 1
    tool, arg = sys.argv[1], " ".join(sys.argv[2:])
    with psycopg.connect() as conn:
        if tool == "vector":
            _print_chunks(vector_search(conn, arg))
        elif tool == "keyword":
            _print_chunks(keyword_search(conn, arg))
        else:
            outgoing, incoming = graph_links(conn, arg)
            print(f"Liens sortants ({len(outgoing)}) :")
            for url, title, ingested in outgoing:
                print(f"  {'●' if ingested else '○'} {url}  {title or ''}")
            print(f"\nLiens entrants ({len(incoming)}) :")
            for url, title, _ in incoming:
                print(f"  ● {url}  {title}")
            print("\n● page en base   ○ page hors périmètre (pas encore ingérée)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
